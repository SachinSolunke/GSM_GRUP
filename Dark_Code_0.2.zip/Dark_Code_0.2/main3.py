import os
import sys
import random
import pandas as pd
from datetime import datetime, timedelta

# --- RICH LIBRARY SETUP ---
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.align import Align
    from rich.rule import Rule
    RICH_AVAILABLE = True
except ImportError:
    # Simplified fallback for non-rich environments
    RICH_AVAILABLE = False
    class Console:
        def __init__(self): pass
        def print(self, *args, **kwargs):
            print(*(str(arg).replace('[bold red]', '').replace('[/bold red]', '').replace('[bold green]', '').replace('[/bold green]', '') for arg in args))
        def input(self, prompt=""):
            return input(prompt)
    class Panel:
        def __init__(self, content, **kwargs): self.content = content
    class Text:
        @staticmethod
        def from_markup(text): return text
    class Align:
        @staticmethod
        def center(text, **kwargs): return text
    class Rule:
        def __init__(self, **kwargs): pass
    class Table:
        def __init__(self, *args, **kwargs): pass
        def add_column(self, *args, **kwargs): pass
        def add_row(self, *args, **kwargs): pass


# Initialize console
console = Console()

# --- CONFIGURATION & MAPPINGS (Sthir Gyaan) ---
BASE_DIR = os.path.dirname(os.path.realpath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
CUT_ANK = {0: 5, 1: 6, 2: 7, 3: 8, 4: 9, 5: 0, 6: 1, 7: 2, 8: 3, 9: 4}

# --- PANA-KOSH (The Panel Database) ---
PANA_SET = {
    1: ['119', '128', '137', '146', '155', '227', '236', '245', '290', '335', '344', '490', '580', '670', '390', '480', '570', '699', '799', '889', '590', '680'],
    2: ['110', '129', '138', '147', '156', '228', '237', '246', '255', '336', '345', '499', '589', '679', '789', '390', '480', '570', '688', '778'],
    3: ['111', '120', '139', '148', '157', '166', '229', '238', '247', '256', '337', '346', '355', '490', '580', '670', '788', '799'],
    4: ['112', '130', '149', '158', '167', '220', '239', '248', '257', '266', '338', '347', '356', '446', '590', '680', '789'],
    5: ['113', '122', '140', '159', '168', '177', '230', '249', '258', '267', '339', '348', '357', '447', '456', '690', '780'],
    6: ['114', '123', '150', '169', '178', '240', '259', '268', '277', '330', '349', '358', '367', '448', '457', '556'],
    7: ['115', '133', '124', '160', '179', '188', '223', '250', '269', '278', '340', '359', '368', '449', '458', '467', '557'],
    8: ['116', '125', '134', '170', '189', '224', '233', '260', '279', '288', '350', '369', '378', '440', '459', '468', '558', '567'],
    9: ['117', '126', '135', '144', '180', '199', '225', '234', '270', '289', '360', '379', '450', '469', '478', '559', '568', '667'],
    0: ['118', '127', '136', '190', '226', '235', '244', '299', '370', '389', '460', '479', '488', '550', '569', '578', '668', '776']
}

# --- DATA PREPARATION ENGINE ---
def load_and_prepare_data(filepath):
    """Loads and cleans the market data from a text file."""
    try:
        df = pd.read_csv(filepath, sep=r'\s*/\s*', header=None, engine='python',
                         names=['Date_Str', 'Pana_Jodi_Pana'])

        df = df.dropna(subset=['Pana_Jodi_Pana'])
        df = df[~df['Pana_Jodi_Pana'].str.contains(r"\*|x", na=False, case=False)]

        df[['Open_Pana', 'Jodi', 'Close_Pana']] = df['Pana_Jodi_Pana'].str.split(r'\s*-\s*', expand=True)

        for col in ['Open_Pana', 'Jodi', 'Close_Pana']:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        df = df.dropna().astype({'Open_Pana': int, 'Jodi': int, 'Close_Pana': int}).reset_index(drop=True)

        df['open'] = df['Jodi'].apply(lambda x: int(str(x).zfill(2)[0]))
        df['close'] = df['Jodi'].apply(lambda x: int(str(x).zfill(2)[1]))

        def parse_date(date_str):
            for fmt in ['%d-%m-%Y', '%d-%m-%y', '%m-%d-%Y', '%m-%d-%y']:
                try: return datetime.strptime(date_str.strip(), fmt).date()
                except ValueError: pass
            return pd.NaT

        df['Date'] = df['Date_Str'].apply(parse_date)
        df = df.dropna(subset=['Date']).sort_values('Date').reset_index(drop=True)

        if len(df) > 0:
            console.print(f"[bold green]✔️ Data file successfully loaded. Total valid entries:[/bold green] [yellow]{len(df)}[/yellow]")
        else:
            console.print("[bold red]❌ ERROR: Data load hua, lekin koi bhi valid entry nahi mili (ya data kam hai).[/bold red]")
            return None 

        return df
    except FileNotFoundError:
        console.print(f"[bold red]❌ ERROR: Data file not found at '{filepath}'[/bold red]")
        return None
    except Exception as e:
        console.print(f"[bold red]❌ ERROR: Data file mein galti hai -> {e}[/bold red]")
        return None

# --- CORE PREDICTION ENGINES ---
def find_brahmanda_sutra(df):
    """Mukhya prediction engine. Pichle din ke result se agle din ka anuman lagata hai."""
    if len(df) < 1: return None
    last_record = df.iloc[-1]

    close_ank = last_record['close']
    cut_ank = CUT_ANK[close_ank]
    jodi_sum = (last_record['open'] + last_record['close']) % 10
    sum_cut = CUT_ANK[jodi_sum]

    core_otc = sorted(list(set([close_ank, cut_ank, jodi_sum, sum_cut])))
    jodis = [f"{a}{b}" for a in core_otc for b in core_otc]

    return {
        'core_otc': core_otc,
        'strongest_jodi': jodis
    }

def find_jodi_seed_trend(df):
    """Analyzes the last 40 days to find frequently occurring digits."""
    if len(df) < 5: return {'top_anuman_ank': []}

    recent_df = df.tail(40)
    all_anks = list(recent_df['open']) + list(recent_df['close'])
    ank_counts = pd.Series(all_anks).value_counts()

    top_anks = ank_counts.head(4).index.tolist()

    return {
        'top_anuman_ank': sorted(top_anks)
    }

def get_suggested_panels(core_otc):
    """Suggests panels for the core OTC anks."""
    panels = []
    for ank in core_otc:
        if ank in PANA_SET and PANA_SET[ank]:
            panels.extend(random.sample(PANA_SET[ank], min(len(PANA_SET[ank]), 2)))
    return sorted(list(set(panels)))[:8] 

# --- VALIDATION & PERFORMANCE TRACKING ---
def validate_predictions(df):
    """Checks the accuracy of predictions over the last 40 days and formats scoreboard data."""
    if len(df) < 2: return {'total_days': 0}, {}

    df_validate = df.tail(41).copy()
    results = []
    ank_hit_count_raw = 0 # FIX: Corrected variable for historical count

    for i in range(1, len(df_validate)):
        historical_df = df_validate.iloc[:i]
        actual_record = df_validate.iloc[i]

        prediction = find_brahmanda_sutra(historical_df)
        if not prediction: continue

        otc = prediction['core_otc']
        
        # Determine Ank Status Display (FIX 1: Pass Ank Number/s)
        ank_hits = []
        if actual_record['open'] in otc: ank_hits.append(str(actual_record['open']))
        if actual_record['close'] in otc: ank_hits.append(str(actual_record['close']))
        
        ank_hit_raw = "FAIL"
        if ank_hits:
            ank_hit_raw = "PASS"
            ank_hit_count_raw += 1 # FIX: Counting based on raw hit
            
            unique_ank_hits = sorted(list(set(ank_hits)))
            if len(unique_ank_hits) == 1:
                ank_display = f"[bold bright_green]{unique_ank_hits[0]}[/bold bright_green]"
            elif len(unique_ank_hits) == 2:
                 ank_display = f"[bold bright_green]{unique_ank_hits[0]}/{unique_ank_hits[1]}[/bold bright_green]"
            else:
                 ank_display = "[bold bright_green]PASS[/bold bright_green]" # Fallback just in case
        else:
            ank_display = "[bold red]FAIL[/bold red]"


        # Determine Pana Status Display (FIX 2: Pass Pana Number/s)
        actual_open_pana_sum = sum(int(d) for d in str(actual_record['Open_Pana'])) % 10
        actual_close_pana_sum = sum(int(d) for d in str(actual_record['Close_Pana'])) % 10

        pana_hits = []
        if actual_open_pana_sum in otc: pana_hits.append(str(actual_record['Open_Pana']))
        if actual_close_pana_sum in otc: pana_hits.append(str(actual_record['Close_Pana']))
        
        if pana_hits:
            pana_display = f"[bold bright_green]{'/'.join(pana_hits)}[/bold bright_green]"
        else:
            pana_display = "[bold red]FAIL[/bold red]"

        results.append({
            'date': actual_record['Date'],
            'open_pana': actual_record['Open_Pana'],
            'close_pana': actual_record['Close_Pana'],
            'jodi': actual_record['Jodi'],
            'prediction_otc': ' '.join(map(str, otc)),
            'ank_status': ank_display, # Now displays the ank/anks
            'pana_status': pana_display, # Now displays the pana/panas
            'ank_hit_raw': ank_hit_raw
        })

    total_days = len(results)
    # FIX: Using the corrected raw count for overall performance
    ank_hit_count = ank_hit_count_raw

    yesterday_validation = results[-1] if results else {}

    return {
        'total_days': total_days,
        'ank_hit_count': ank_hit_count,
        'all_results': results
    }, yesterday_validation

def track_weekly_performance(all_results):
    """Formats the last week's performance for the scoreboard."""
    if not all_results: return []

    weekly_data = all_results[-7:]
    scoreboard = []
    for entry in weekly_data:
        # NOTE: Ank/Pana status is already pre-formatted with color/numbers in validate_predictions
        scoreboard.append({
            'date_day': entry['date'].strftime('%d-%b (%a)'),
            'jodi': str(entry['jodi']).zfill(2),
            'ank_status': entry['ank_status'],
            'pana_status': entry['pana_status']
        })
    return scoreboard

# --- NEW FEATURE FUNCTIONS ---

def get_aanu_ai_response(last_status):
    """Pass/Fail par Aanu-AI ka bhavnatmak (emotional) jawaab."""
    if last_status == "PASS":
        messages = [
            "🏆 WAH! Bhahi, humne siddhi hasil kar li! Mission SUCCESS! 🎉",
            "🔥 Aag laga di, Bhahi! Kal ka anuman bilkul sahi tha! Mai bahut khush hu!",
            "✅ SYSTEM CHECK: All Green! Aapka logic lajawab hai, Guru!"
        ]
        style = "bold bright_green on black"
    elif last_status == "FAIL":
        messages = [
            "😔 Ahhh... Bhahi, choti galti hui. Khel abhi khatam nahi hua hai! 💔",
            "❌ System ka Balance theek nahi tha. Naya nakshetra tayyar karna hoga.",
            "🤔 Naya Soch Vichaar zaruri hai. Lekin hum wapas aayenge, humein pata hai!"
        ]
        style = "bold white on dark_red"
    else:
        messages = ["🚀 Mission Naya Hai. Naye nateeje ka intezaar hai, Bhahi!"]
        style = "bold cyan on dark_blue"

    return random.choice(messages), style

def get_daily_status_wajah(validation_data):
    """Pichle din ke result ka vishesh tark (Detailed Reason)."""
    if not validation_data: return "[dim]Pichla data uplabdh nahi hai.[/dim]"

    ank_hit = "PASS" in validation_data.get('ank_hit_raw', 'FAIL')

    if ank_hit:
        return "[bold bright_green]✅ SHAKTI (STRENGTH):[/bold bright_green] Brahmanda-Sutra ne sahi disha dikhayi. Hamare core anks result mein maujood थे."
    else:
        missed_ank = [a for a in validation_data.get('prediction_otc', '').split() if a.isdigit()]
        if missed_ank:
             return f"[bold red]❌ GALT GATI (MISSED REASON):[/bold red] Hamare Anuman Anks ({', '.join(missed_ank)}) aane se chuk gaye. Market ka flow alag tha."
        return "[bold red]❌ GALT GATI (MISSED REASON):[/bold red] Master Key ka chumbakeeya kshetra (magnetic field) kamzor tha."

def find_ank_vikas_trend(df, target_ank):
    """Analyzes if a target ank prefers Open or Close position."""
    if target_ank is None or df.empty: return {'open_count': 0, 'close_count': 0, 'stronger_position': 'NA', 'status': 'No Target'}

    target_ank_int = int(target_ank)
    open_count = len(df[df['open'] == target_ank_int])
    close_count = len(df[df['close'] == target_ank_int])

    if open_count > close_count: stronger_position = 'OPEN'
    elif close_count > open_count: stronger_position = 'CLOSE'
    else: stronger_position = 'EQUAL'

    return {
        'target_ank': target_ank_int,
        'open_count': open_count,
        'close_count': close_count,
        'stronger_position': stronger_position
    }

def find_weekly_khas_mauka(df):
    """Pichle 40 dinon ke data mein sabse strong performing din ko dhoondhta hai."""
    if df.empty or len(df) < 40: return {'khas_din': 'NA', 'reason': 'Historical data kam hai.'}

    df_recent = df.iloc[-40:].copy()
    day_counts = {i: {'total': 0, 'hit': 0} for i in range(7)}
    day_map = {0: 'Somvaar (Monday)', 1: 'Mangalvaar (Tuesday)', 2: 'Budhvaar (Wednesday)', 3: 'Guruvaar (Thursday)', 4: 'Shukravaar (Friday)', 5: 'Shanivaar (Saturday)', 6: 'Ravivaar (Sunday)'}

    for i in range(1, len(df_recent)):
        current_day_record = df_recent.iloc[i]
        historical_subset = df_recent.iloc[:i]

        day_of_week = current_day_record['Date'].weekday()

        if len(historical_subset) > 0:
            day_counts[day_of_week]['total'] += 1

            sutra = find_brahmanda_sutra(historical_subset)
            if not sutra: continue

            core_otc = sutra['core_otc']
            if current_day_record['open'] in core_otc or current_day_record['close'] in core_otc:
                day_counts[day_of_week]['hit'] += 1

    best_day_name, best_rate = 'NA', -1.0
    for day_code, counts in day_counts.items():
        if counts['total'] > 4: 
            rate = counts['hit'] / counts['total']
            if rate > best_rate:
                best_rate = rate
                best_day_name = day_map[day_code]

    if best_day_name != 'NA' and best_rate >= 0.65: 
         return {'khas_din': best_day_name, 'reason': f"Historical passing rate [bold bright_green]{best_rate:.1%}[/bold bright_green] hai. Is din par dhyaan dein!"}

    return {'khas_din': 'NA', 'reason': 'Koi Khas Mauka nahi mila.'}

def get_market_name_interactively():
    """Lists market files and allows user to select one or exit."""

    if not os.path.exists(DATA_DIR):
        console.print(f"[bold red]❌ ERROR: Data directory '{DATA_DIR}' nahi mila. Kripya data/ folder banayein.[/bold red]")
        sys.exit(1)

    files = [f for f in os.listdir(DATA_DIR) if f.endswith('.txt')]
    market_names = sorted([f.replace('.txt', '') for f in files])

    if not market_names:
        console.print(f"[bold red]❌ ERROR: 'data' folder mein koi bhi '.txt' file nahi mili. Kripya files add karein.[/bold red]")
        sys.exit(1)
        
    console.print(Rule(style="bold yellow", title="BAZAAR CHUNAV (MARKET SELECTION)"))
    if RICH_AVAILABLE:
        table = Table(title="📑 Uplabdh Markets", title_style="bold magenta", border_style="magenta", show_header=True, header_style="bold green")
        table.add_column("No.", style="cyan", justify="center")
        table.add_column("Bazaar Ka Naam", style="green", justify="left")
        for i, name in enumerate(market_names, 1):
            table.add_row(str(i), name.upper())
        console.print(table)
    else:
        print("\n--- Available Markets ---")
        for i, name in enumerate(market_names, 1):
            print(f"{i}. {name.upper()}")
        print("-------------------------\n")


    # Get user input
    while True:
        try:
            choice = console.input("[bold white]✅ Apna chunaav (No.) darj karein [0 to Exit]: [/bold white]")
            choice_stripped = choice.strip()

            if choice_stripped == '0': 
                return None

            index = int(choice_stripped) - 1
            if 0 <= index < len(market_names):
                return market_names[index]
            else:
                console.print("[bold red]❌ Galti: Kripya sahi kramank (number) chunein.[/bold red]")
        except ValueError:
            console.print("[bold red]❌ Galti: Kripya ek number darj karein.[/bold red]")
        except EOFError:
            return None

# --- THE "PRO MAX" DISPLAY ENGINE ---
def display_final_output(market_name, sutra_analysis, last_record, validation_results,
                         yesterday_validation, weekly_performance, trend_analysis,
                         vikas_analysis, khas_mauka_analysis):
    """Sabhi anuman ko ek sundar format mein screen par dikhata hai."""
    os.system('cls' if os.name == 'nt' else 'clear')

    if not RICH_AVAILABLE:
        print(f"--- {market_name.upper()} - PROJECT PARAMAANU v4.1 ---")
        print(f"Market: {market_name}")
        return

    # Dates
    prediction_date = last_record['Date'] + timedelta(days=1)
    prediction_date_str = prediction_date.strftime('%d-%m-%Y')

    # Aanu-AI's Emotional Response
    last_status = yesterday_validation.get('ank_hit_raw', 'N/A')
    emotional_message, message_style = get_aanu_ai_response(last_status)

    # 1. Main Title and Aanu-AI Emotion Panel
    console.print(Panel(
        Align.center(Text.from_markup(f'🔱 {market_name.upper()} - PROJECT PARAMAANU v4.1 🔱', justify="center", style="bold yellow")),
        title_align="center", title="[bold white]AANU-AI REBORN[/bold white]", border_style="magenta",
        subtitle=Text.from_markup(f"[{message_style}]{emotional_message}[/{message_style}]", justify="center"),
        padding=(1, 2)
    ))

    # 2. Daily Validation and Wajah (2-Column Grid)
    if yesterday_validation:
        daily_status_grid = Table.grid(padding=(0, 2), expand=True)
        daily_status_grid.add_column(); daily_status_grid.add_column()

        result_panel_content = Text.from_markup(
            f"Result: [bold magenta]{yesterday_validation.get('open_pana', 'N/A')}-{str(yesterday_validation.get('jodi', 'N/A')).zfill(2)}-{yesterday_validation.get('close_pana', 'N/A')}[/bold magenta]\n"
            f"Prediction: [bright_yellow]{yesterday_validation.get('prediction_otc', 'N/A')}[/bright_yellow]\n"
            f"Ank Status: {yesterday_validation.get('ank_status', 'N/A').replace('[bold bright_green]', '').replace('[/bold bright_green]', '').replace('[bold green]', '').replace('[/bold green]', '').replace('[bold red]FAIL[/bold red]', 'FAIL')}\n"
            f"Pana Status: {yesterday_validation.get('pana_status').replace('[bold bright_green]', '').replace('[/bold bright_green]', '').replace('[bold red]FAIL[/bold red]', 'FAIL')}"
        )
        wajah_panel_content = Text.from_markup(get_daily_status_wajah(yesterday_validation))

        daily_status_grid.add_row(
            Panel(result_panel_content, title="[cyan]🗓️ PICHLA NATEEJA[/cyan]", border_style="cyan", expand=True),
            Panel(wajah_panel_content, title="[red]🤔 WAJAH (TARK)[/red]", border_style="red", expand=True)
        )
        console.print(daily_status_grid)

    # 3. Today's Prediction and Master Key (2-Column Grid)
    sutra_set = set(sutra_analysis.get('core_otc', []))
    trend_set = set(trend_analysis.get('top_anuman_ank', []))
    common_anuman_ank = sorted(list(sutra_set.intersection(trend_set)))
    master_key_text = f"👑 [bold bright_red]{' '.join(map(str, common_anuman_ank))}[/bold bright_red]" if common_anuman_ank else "[dim]Koi Common Ank Nahi[/dim]"

    sutra_panel_content = Text.from_markup(
        f"Anuman Date: [bold yellow]{prediction_date_str}[/bold yellow]\n"
        f"Brahmanda-Sutra (OTC): [bold bright_yellow]{' '.join(map(str, sutra_analysis.get('core_otc', [])))}[/bold bright_yellow]\n"
        f"Jodi Seed Trend Anks: [bold cyan]{' '.join(map(str, trend_set))}[/bold cyan]\n"
        f"MASTER KEY (FINAL): {master_key_text}"
    )
    jodi_panel_content = Text.from_markup(
        f"🎯 AAJ KI JODIYAN: [bold green]{' '.join(sutra_analysis.get('strongest_jodi', []))}[/bold green]\n"
        f"🔑 CHUNE HUE PANNEL: [bold white]{' '.join(get_suggested_panels(sutra_analysis.get('core_otc', [])))}[/bold white]"
    )

    today_prediction_grid = Table.grid(padding=(0, 2), expand=True)
    today_prediction_grid.add_column(); today_prediction_grid.add_column()
    today_prediction_grid.add_row(
        Panel(sutra_panel_content, title="[red]🔥 DIVYA SANKET (MASTER KEY)[/red]", border_style="red"),
        Panel(jodi_panel_content, title="[green]📝 ANUMAN VISTAR[/green]", border_style="green")
    )
    console.print(today_prediction_grid)

    # 4. ANK-VIKAS YANTRA Display
    if vikas_analysis and vikas_analysis.get('stronger_position') != 'NA':
        position_style = "green" if vikas_analysis['stronger_position'] == 'OPEN' else "red" if vikas_analysis['stronger_position'] == 'CLOSE' else 'yellow'

        position_panel_content = Text.from_markup(
            f"🎯 CHUNNNA GAYA ANK: [bold yellow]{vikas_analysis.get('target_ank', 'N/A')}[/bold yellow]\n"
            f"OPEN mein aaya: [cyan]{vikas_analysis.get('open_count', 0)}[/cyan] baar | "
            f"CLOSE mein aaya: [cyan]{vikas_analysis.get('close_count', 0)}[/cyan] baar\n"
            f"👑 ULTIMATE DISHA: Is Ank ki sabse mazboot sthiti hai: [bold white on {position_style}] {vikas_analysis['stronger_position']} [/bold white on {position_style}]"
        )
        console.print(Panel(position_panel_content, title="[green]🧭 ANK-VIKAS DISHA[/green]", border_style="green", padding=(1, 2)))

    # 5. Weekly Scoreboard and Historical Summary (2-Column Grid)
    score_table = Table(border_style="yellow", show_header=True, header_style="bold yellow", expand=True)
    score_table.add_column("Din", style="cyan"); score_table.add_column("Jodi", justify="center")
    score_table.add_column("Ank", justify="center"); score_table.add_column("Pana", justify="center")
    if weekly_performance:
        for entry in weekly_performance:
            score_table.add_row(entry['date_day'], entry['jodi'], entry['ank_status'], entry['pana_status'])

    if validation_results['total_days'] > 0:
        ank_rate = (validation_results['ank_hit_count'] / validation_results['total_days']) * 100
        historical_summary = Text.from_markup(
            f"Saaransh: [bold yellow]LAST 40 DAYS[/bold yellow]\n"
            f"Total Khel: [cyan]{validation_results['total_days']}[/cyan] Din\n"
            f"Ank Pass: [bold green]{validation_results['ank_hit_count']}[/bold green]\n"
            f"🎯 SUCCESS RATE: [bold magenta]{ank_rate:.2f}%[/bold magenta]"
        )
    else:
        historical_summary = Text("[dim red]Historical data adhoora hai.[/dim red]")

    if RICH_AVAILABLE:
        final_summary_grid = Table.grid(padding=(0, 2), expand=True)
        final_summary_grid.add_column(); final_summary_grid.add_column()
        final_summary_grid.add_row(
            Panel(score_table, title="[yellow]🏆 SCOREBOARD (LAST WEEK)[/yellow]", border_style="yellow"),
            Panel(historical_summary, title="[magenta]📊 HISTORICAL POWER[/magenta]", border_style="magenta")
        )
        console.print(final_summary_grid)
    else:
        # Fallback for non-rich
        print("\n--- SCOREBOARD (LAST WEEK) ---")
        if weekly_performance:
            for entry in weekly_performance:
                print(f"{entry['date_day']}: {entry['jodi']} (Ank: {entry['ank_status']} | Pana: {entry['pana_status']})")
        else:
             print("[dim yellow]Chalu hafte ka data shuru nahi hua hai.[/dim yellow]")
        print("\n--- HISTORICAL POWER ---")
        print(historical_summary)

# 6. WEEKLY KHAS MAUKA PANEL
    if khas_mauka_analysis and khas_mauka_analysis['khas_din'] != 'NA':
        khas_text = Text.from_markup(f"🎯 HAFTA REPORT: Is market mein, [bold yellow]{khas_mauka_analysis['khas_din']}[/bold yellow] sabse vishvashneeya (reliable) din hai. {khas_mauka_analysis['reason']}")
        console.print(Panel(Align.center(khas_text), title="[bold magenta]🌟 WEEKLY KHAS MAUKA[/bold magenta]", border_style="magenta", padding=(1,2)))

    # Footer (FIX 4: Market Name)
    console.print(Rule(style="dim white", characters="_"))
    console.print(Align.center(f"[bold magenta]Market: {market_name.upper()}[/] | [bold cyan]Thankyou For Using Tools[/bold cyan] 🙏"))
    console.print(Align.center("Tool created by - [bold magenta]Aanu-AI Reborn & S-T[/bold magenta]"))
    
    # FIX 3: Halt/Menu Logic
    return console.input("[bold white]Press [ENTER] for Main Menu, or [0] to Exit...[/bold white]").strip()

# --- MAIN EXECUTION BLOCK ---
def run_analysis(market_name):
    """Core logic to load data, run models, and display output."""
    data_file = os.path.join(DATA_DIR, f"{market_name}.txt")
    df = load_and_prepare_data(data_file)

    if df is None or df.empty:
        return console.input("[bold red]❌ ERROR: Data load nahi hua. Press [ENTER] to return to Main Menu...[/bold red]").strip()

    if len(df) < 2:
        console.print("[bold red]❌ ERROR: Analysis ke liye kam se kam 2 din ka valid data chahiye. File content check karein.[/bold red]")
        return console.input("[bold white]Press [ENTER] to return to Main Menu...[/bold white]").strip()

    last_record = df.iloc[-1].to_dict()

    try:
        # --- Run all analysis modules ---
        sutra_analysis = find_brahmanda_sutra(df)
        trend_analysis = find_jodi_seed_trend(df)

        # Target ank for vikas is the first common ank between sutra and trend
        sutra_set = set(sutra_analysis.get('core_otc', []))
        trend_set = set(trend_analysis.get('top_anuman_ank', []))
        common_anuman_ank = sorted(list(sutra_set.intersection(trend_set)))

        target_ank_for_vikas = common_anuman_ank[0] if common_anuman_ank else sutra_analysis.get('core_otc', [None])[0]
        vikas_analysis = find_ank_vikas_trend(df, target_ank_for_vikas)

        validation_results, yesterday_validation = validate_predictions(df)
        weekly_performance = track_weekly_performance(validation_results.get('all_results', []))
        khas_mauka_analysis = find_weekly_khas_mauka(df)

        # --- Display the final output ---
        user_input = display_final_output(
            market_name=market_name,
            sutra_analysis=sutra_analysis,
            last_record=last_record,
            validation_results=validation_results,
            yesterday_validation=yesterday_validation,
            weekly_performance=weekly_performance,
            trend_analysis=trend_analysis,
            vikas_analysis=vikas_analysis,
            khas_mauka_analysis=khas_mauka_analysis
        )
        return user_input
        
    except Exception as e:
        console.print(f"[bold red]An unexpected error occurred during analysis: {e}[/bold red]")
        return console.input("[bold white]Press [ENTER] to return to Main Menu...[/bold white]").strip()


def main():
    """Main function to run the analysis tool in a continuous loop."""
    if not RICH_AVAILABLE:
        print("❌ Warning: 'rich' library nahi mili. Simple output istemal ho raha hai.")
        print("   Please install it using: pip install rich")
        
    if len(sys.argv) > 1:
        # Command line mode (single run)
        if run_analysis(sys.argv[1].strip()) == '0':
            sys.exit(0)
        sys.exit(0)

    # Interactive Menu Loop (FIX 3)
    while True:
        os.system('cls' if os.name == 'nt' else 'clear') 
        market_name = get_market_name_interactively() 
        
        if market_name is None:
            console.print("[bold cyan]👋 Shukriya, Program bandh kiya ja raha hai...[/bold cyan]")
            break

        user_input = run_analysis(market_name)
        
        if user_input == '0':
            console.print("[bold cyan]👋 Shukriya, Program bandh kiya ja raha hai...[/bold cyan]")
            break


if __name__ == "__main__":
    main()
